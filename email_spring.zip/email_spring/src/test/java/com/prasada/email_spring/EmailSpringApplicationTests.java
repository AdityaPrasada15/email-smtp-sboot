package com.prasada.email_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
