package com.prasada.email_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailSpringApplication.class, args);
	}

}
